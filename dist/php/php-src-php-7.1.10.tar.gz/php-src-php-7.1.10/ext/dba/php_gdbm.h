#ifndef PHP_GDBM_H
#define PHP_GDBM_H

#if DBA_GDBM

#include "php_dba.h"

DBA_FUNCS(gdbm);

#endif

#endif
