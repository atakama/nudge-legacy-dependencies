int
foo (int x)
{
  return x * 4;
}
