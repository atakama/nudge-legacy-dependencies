tmpdir/ifunc-gdesc.so:     file format elf32-(big|little)arm
DYNAMIC RELOCATION RECORDS
OFFSET   TYPE              VALUE 
0001025c R_ARM_IRELATIVE   \*ABS\*
00010248 R_ARM_TLS_DESC    \*ABS\*
00010250 R_ARM_TLS_DESC    \*ABS\*
