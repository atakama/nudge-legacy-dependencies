void foo(void);

int main(void)
{
   foo ();

   for (;;)
	;
}

int a;

void foo1(void)
{
	a = 1;
}

void foo2(void)
{
	a = 2;
}

void foo3(void)
{
	a = 3;
}


