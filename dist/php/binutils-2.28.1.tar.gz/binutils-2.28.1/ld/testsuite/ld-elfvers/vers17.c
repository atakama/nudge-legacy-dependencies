int
show_foo ()
{
  return 99;
}
