int show_foo;
