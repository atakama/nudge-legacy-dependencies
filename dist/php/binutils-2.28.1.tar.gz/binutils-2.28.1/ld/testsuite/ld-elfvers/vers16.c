int show_bar ()
{
  return 0;
}
extern int show_foo ();

int main ()
{
  return show_foo ();
}
