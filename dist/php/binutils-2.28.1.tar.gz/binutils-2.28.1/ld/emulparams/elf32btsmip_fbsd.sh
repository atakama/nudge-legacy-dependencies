. ${srcdir}/emulparams/elf32btsmip.sh
. ${srcdir}/emulparams/elf_fbsd.sh
OUTPUT_FORMAT="elf32-tradbigmips-freebsd"
BIG_OUTPUT_FORMAT="elf32-tradbigmips-freebsd"
LITTLE_OUTPUT_FORMAT="elf32-tradlittlemips-freebsd"
