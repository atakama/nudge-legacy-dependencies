. ${srcdir}/emulparams/armelf_nbsd.sh
OUTPUT_FORMAT="elf32-bigarm"
