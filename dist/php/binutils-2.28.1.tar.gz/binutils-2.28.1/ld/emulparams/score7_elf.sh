. ${srcdir}/emulparams/score3_elf.sh
ARCH=score7
