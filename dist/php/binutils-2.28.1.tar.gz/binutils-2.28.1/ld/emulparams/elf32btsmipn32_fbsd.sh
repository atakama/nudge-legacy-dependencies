. ${srcdir}/emulparams/elf32ltsmipn32.sh
. ${srcdir}/emulparams/elf_fbsd.sh
OUTPUT_FORMAT="elf32-ntradbigmips-freebsd"
BIG_OUTPUT_FORMAT="elf32-ntradbigmips-freebsd"
LITTLE_OUTPUT_FORMAT="elf32-ntradlittlemips-freebsd"
