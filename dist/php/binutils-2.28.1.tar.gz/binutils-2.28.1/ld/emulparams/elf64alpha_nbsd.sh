. ${srcdir}/emulparams/elf64alpha.sh
ENTRY=__start
