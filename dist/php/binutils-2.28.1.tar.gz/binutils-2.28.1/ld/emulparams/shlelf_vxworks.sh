. ${srcdir}/emulparams/shelf_vxworks.sh
OUTPUT_FORMAT="$LITTLE_OUTPUT_FORMAT"
