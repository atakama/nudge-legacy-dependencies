. ${srcdir}/emulparams/elf_l1om.sh
. ${srcdir}/emulparams/elf_fbsd.sh
OUTPUT_FORMAT="elf64-l1om-freebsd"
