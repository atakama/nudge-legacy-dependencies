ARCH=arm
SCRIPT_NAME=armcoff
OUTPUT_FORMAT="coff-arm-little"
LITTLE_OUTPUT_FORMAT="coff-arm-little"
BIG_OUTPUT_FORMAT="coff-arm-big"
TEMPLATE_NAME=armcoff
