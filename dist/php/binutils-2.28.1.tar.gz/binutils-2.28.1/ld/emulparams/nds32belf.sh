. ${srcdir}/emulparams/nds32elf.sh
OUTPUT_FORMAT="$BIG_OUTPUT_FORMAT"
