. ${srcdir}/emulparams/elf64btsmip.sh
. ${srcdir}/emulparams/elf_fbsd.sh
OUTPUT_FORMAT="elf64-tradbigmips-freebsd"
BIG_OUTPUT_FORMAT="elf64-tradbigmips-freebsd"
LITTLE_OUTPUT_FORMAT="elf64-tradlittlemips-freebsd"
