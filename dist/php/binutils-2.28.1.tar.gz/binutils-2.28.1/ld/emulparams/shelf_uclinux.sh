. ${srcdir}/emulparams/shelf.sh

# We do not want a .stack section
OTHER_SECTIONS=""
