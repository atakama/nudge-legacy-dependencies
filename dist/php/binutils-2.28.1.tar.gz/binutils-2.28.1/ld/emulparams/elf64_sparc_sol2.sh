. ${srcdir}/emulparams/elf64_sparc.sh
. ${srcdir}/emulparams/solaris2.sh
EXTRA_EM_FILE=solaris2
OUTPUT_FORMAT="elf64-sparc-sol2"
