. ${srcdir}/emulparams/aarch64linux32.sh
OUTPUT_FORMAT="elf32-bigaarch64"
ELF_INTERPRETER_NAME=\"/lib/ld-linux-aarch64_be_ilp32.so.1\"
