# If you change this file, please also look at files which source this one:
# shl.sh

SCRIPT_NAME=sh
OUTPUT_FORMAT="coff-sh"
TEXT_START_ADDR=0x8000
TARGET_PAGE_SIZE=128
ARCH=sh
