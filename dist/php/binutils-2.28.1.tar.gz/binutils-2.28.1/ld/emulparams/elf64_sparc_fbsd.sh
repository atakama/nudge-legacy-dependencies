. ${srcdir}/emulparams/elf64_sparc.sh
. ${srcdir}/emulparams/elf_fbsd.sh

OUTPUT_FORMAT="elf64-sparc-freebsd"
