. ${srcdir}/emulparams/aarch64fbsd.sh
OUTPUT_FORMAT="elf64-bigaarch64"
