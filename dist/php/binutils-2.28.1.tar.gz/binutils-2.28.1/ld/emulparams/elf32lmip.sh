# If you change this file, please also look at files which source this one:
# elf32elmip.sh elf32lsmip.sh

. ${srcdir}/emulparams/elf32bmip.sh
OUTPUT_FORMAT="elf32-littlemips"
BIG_OUTPUT_FORMAT="elf32-bigmips"
LITTLE_OUTPUT_FORMAT="elf32-littlemips"
