. ${srcdir}/emulparams/elf32ppccommon.sh
. ${srcdir}/emulparams/plt_unwind.sh
EXTRA_EM_FILE=ppc32elf
OUTPUT_FORMAT="elf32-powerpc-vxworks"
. ${srcdir}/emulparams/vxworks.sh
