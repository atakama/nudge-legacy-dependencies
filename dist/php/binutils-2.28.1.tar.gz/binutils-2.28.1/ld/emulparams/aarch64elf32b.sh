. ${srcdir}/emulparams/aarch64elf32.sh
OUTPUT_FORMAT="elf32-bigaarch64"
