. ${srcdir}/emulparams/elf_x86_64.sh
OUTPUT_FORMAT="elf64-x86-64-cloudabi"
