. ${srcdir}/emulparams/elf_i386_ldso.sh
. ${srcdir}/emulparams/solaris2.sh
EXTRA_EM_FILE=solaris2
OUTPUT_FORMAT="elf32-i386-sol2"
