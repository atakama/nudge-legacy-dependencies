OUTPUT_FORMAT="elf32-sh64l"
. ${srcdir}/emulparams/shelf32.sh
