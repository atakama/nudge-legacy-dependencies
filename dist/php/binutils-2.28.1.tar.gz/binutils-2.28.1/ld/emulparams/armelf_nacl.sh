. ${srcdir}/emulparams/armelf_linux_eabi.sh
. ${srcdir}/emulparams/elf_nacl.sh
BIG_OUTPUT_FORMAT="elf32-bigarm-nacl"
LITTLE_OUTPUT_FORMAT="elf32-littlearm-nacl"
OUTPUT_FORMAT="$LITTLE_OUTPUT_FORMAT"
