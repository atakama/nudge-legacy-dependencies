OUTPUT_FORMAT="elf64-sh64l"
. ${srcdir}/emulparams/shelf64.sh
